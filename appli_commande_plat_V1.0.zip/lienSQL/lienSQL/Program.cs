﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace ConsoleApp37
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Saisir utilisateur (Cuisinier ou Client) :");
            string uti = Console.ReadLine();
            Console.WriteLine("Saisir le mot de passe : ");
            string pswd = Console.ReadLine();

            string connectionString = $"SERVER=localhost;PORT=3306;DATABASE=projet;UID={uti};PASSWORD={pswd};";
            MySqlConnection maConnection = new MySqlConnection(connectionString);
            bool connec = false;

            while (!connec)
            {
                try
                {
                    maConnection.Open();
                    connec = true;
                }
                catch (MySqlException ex)
                {
                    switch (ex.Number)
                    {
                        case 0:
                            Console.WriteLine("Impossible de se connecter.");
                            break;
                        case 1045:
                            Console.WriteLine("Mauvais identifiant ou mot de passe.");
                            break;
                    }

                    Console.WriteLine("Nouvel essai - saisir utilisateur :");
                    uti = Console.ReadLine();
                    Console.WriteLine("Saisir le mot de passe :");
                    pswd = Console.ReadLine();
                    connectionString = $"SERVER=localhost;PORT=3306;DATABASE=projet;UID={uti};PASSWORD={pswd};";
                    maConnection = new MySqlConnection(connectionString);
                }
            }

            // Appel de la méthode avec la bonne connexion
           

            Console.Clear();
            List<string> listeplat = new List<string>(); // pour le client
            while (true)
            {
                if(uti == "Client")
                {
                    
                 

                    Console.WriteLine("interface Client");

                    string platoupannier;
                    Console.WriteLine("selectionner plat ou valider panier ?  plat/panier");
                    platoupannier = Saisiestring("plat", "panier");

                    if (platoupannier == "plat")
                    {
                        Console.WriteLine("plat : ");
                        string platchoisi = AfficherPlats(maConnection);
                        Console.Clear();
                        Afficher_Ingrédient(maConnection, platchoisi);
                        Afficher_avis_du_plat_du_cuisinier(maConnection, platchoisi);
                        Console.WriteLine("Souhouaitez vous ajouter ce plat au panier ?  oui/non :");
                        string réponse = Saisiestring("oui", "non");
                        if (réponse == "oui")
                        {
                            listeplat.Add(platchoisi);
                            Console.WriteLine("saisir lieu de livraision");

                            listeplat.Add("au "+Console.ReadLine()); 
                        }
                        Console.WriteLine("Contenu du panier : ");
                        foreach (var a in listeplat)
                        {
                            Console.WriteLine(a);
                        }
                        Console.ReadLine();
                        Console.Clear();
                    }
                    if (platoupannier == "panier")
                    {
                        Console.Clear();
                        Console.WriteLine("Contenu du panier : ");
                        foreach ( var a in listeplat )
                        {
                            Console.WriteLine(a);
                        }
                        ticketdecaisse(listeplat);
                        break;
                    }




                    }

                else
                {

                    Console.Write("interface cuisinier");
                    break;
                }
                
            }
            maConnection.Close();



            
        }

        

        static string AfficherPlats(MySqlConnection maConnection)
        {
            string platchoisi = "" ;
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = "SELECT \r\n    Nom_plat, \r\n    Prix, \r\n    Nationalité, \r\n    Nom AS Nom_Cuisinier, \r\n    (SELECT AVG(Note) \r\n     FROM avis \r\n     WHERE avis.Id_Cuisinier = Cuisinier.Id_Cuisinier) AS Note_Cuisinier\r\nFROM Cuisinier\r\nJOIN utilisateur ON Cuisinier.id_utilisateur = utilisateur.id_utilisateur\r\nJOIN Plat ON Plat.Id_Cuisinier = Cuisinier.Id_Cuisinier;";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\nListe des plats :");

                string[] valuestring = new string[reader.FieldCount];
                List<string> platsDisponibles = new List<string>();// pour liste verif
                while (reader.Read())
                {
                    
                    valuestring[0] = reader.GetValue(0).ToString();
                    platsDisponibles.Add(valuestring[0]); // pour liste verif
                    Console.WriteLine(valuestring[0] + ":");
                    for (int i = 1; i < reader.FieldCount; i++)
                    {
                        string s0 = "";
                        string s1 = "";
                        if (i == 1) { s0 = " euros"; }
                        if (i == 2) { s1 = "nationalité "; }
                        if (i == 3) { s1 = "cuisinier : "; }
                        if (i == 4) { s1 = "note : "; }

                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write(s1+valuestring[i] + s0+"\t\t");
                        
                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }
                Console.WriteLine("Choisissez un plat"); // mtn il faut : l'avi en entier / les ingrédient / si on veut le commander

                // Saisie sécurisée
                Console.WriteLine("Choisissez un plat parmi la liste :");

                
                bool platValide = false;

                while (!platValide)
                {
                    Console.Write("Nom du plat : ");
                    platchoisi = Console.ReadLine();

                    if (platsDisponibles.Contains(platchoisi))
                    {
                        platValide = true;
                    }
                    else
                    {
                        Console.WriteLine("Plat invalide. Veuillez réessayer.");
                    }
                }

                // saisi sécu fin

                return platchoisi;
                


            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
                return platchoisi;
            }
        }

        static void Afficher_Ingrédient(MySqlConnection maConnection, string platchoisi)
        {
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = $"SELECT \r\n    i.Nom AS Nom_ingredient,\r\n    i.Origine,\r\n    i.Régime_alimentaire,\r\n    i.certification\r\nFROM \r\n    Plat_Ingredient pi\r\nJOIN \r\n    Ingrédient i ON pi.Nom_ingredient = i.Nom\r\nWHERE \r\n    pi.Nom_plat = '{platchoisi}';";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\ninggrédient du plat :");

                string[] valuestring = new string[reader.FieldCount];
                while (reader.Read())
                {
                    valuestring[0] = reader.GetValue(0).ToString();
                    Console.WriteLine(valuestring[0] + ":");
                    for (int i = 1; i < reader.FieldCount; i++)
                    {
                      

                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write( valuestring[i] + "\t\t");

                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }
              




            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
            }
        }

        static void Afficher_avis_du_plat_du_cuisinier(MySqlConnection maConnection, string platchoisi)
        {
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = $"SELECT u.Prénom,u.Nom,a.Note,a.Titre,a.Commentaire FROM Plat p JOIN    Cuisinier c ON p.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN \r\n    avis a ON a.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN \r\n    Client cl ON a.Id_Client = cl.Id_Client\r\nJOIN \r\n    utilisateur u ON cl.id_utilisateur = u.id_utilisateur\r\nWHERE \r\n    p.Nom_plat = '{platchoisi}';";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\nAvis du Cuisinier:");

                string[] valuestring = new string[reader.FieldCount];
                while (reader.Read())
                {
                    valuestring[0] = reader.GetValue(0).ToString();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        string s0 = "";
                        string s1 = "";
                        if (i == 0) { s0 = " "; }
                        if (i == 1) { s0 = " "; }
                        if (i == 2) { s0 = "/5"; }
                        if (i == 3) { s1 = "\n"; }
                        if (i == 4) { s1 = ", "; }


                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write(s1 + valuestring[i] + s0);

                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }
                




            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
            }
        }





        /// <summary>
        /// créé un reçu pour le client et utilisable pas le cuisinier pour la livraision
        /// </summary>
        /// <param name="contenuListe"></param>
        static void ticketdecaisse(List<string> contenuListe)
        {
            string cheminBinDebugNet6 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin", "Debug", "net6.0");
            string identifiantAleatoire = Guid.NewGuid().ToString();
            string nomFichier = Path.Combine(cheminBinDebugNet6, $"liste_{identifiantAleatoire}.txt");


            if (!Directory.Exists(cheminBinDebugNet6))
            {
                Directory.CreateDirectory(cheminBinDebugNet6); // Créer le dossier s'il n'existe pas
            }

            using (StreamWriter writer = new StreamWriter(nomFichier))
            {
                foreach (string ligne in contenuListe)
                {
                    writer.WriteLine(ligne);
                }
            }

            Console.WriteLine($"Le reçu a été créé avec succès, il est enregistré dans :\n'{nomFichier}'");

        }

        /// <summary>
        /// saisi sécurisé entre 2 string
        /// </summary>
        static string Saisiestring(string x, string y)
        {
            string val = "";
            while (true)
            {
                string st = Console.ReadLine();   // string a tester

                if (st == x || st == y) // si c'est dans l'interval 
                {
                    val = st;
                    break;
                }
                else
                {
                    Console.WriteLine($"il faut que ce sois {x} ou {y} ");
                }
            }
            return val;
        }

    }
}
