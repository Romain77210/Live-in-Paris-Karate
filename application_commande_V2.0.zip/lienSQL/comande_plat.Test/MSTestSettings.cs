﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TonProjet; // Remplace par le namespace de ton projet principal

namespace TonProjet.Tests
{
    [TestClass]
    public class MonTest
    {
        [TestMethod]
        public void TestAddition()
        {
            // Arrange
            var calc = new Calculatrice();

            // Act
            int resultat = calc.Add(2, 3);

            // Assert
            Assert.AreEqual(5, resultat);
        }
    }
}
