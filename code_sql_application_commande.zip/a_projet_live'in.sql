set sql_safe_updates=0;
drop database if exists projet;
create database if not exists projet;
use projet;
CREATE TABLE Ingrédient(
   Nom VARCHAR(50),
   Origine VARCHAR(50),
   Régime_alimentaire VARCHAR(50),
   certification VARCHAR(50),
   PRIMARY KEY(Nom)
);

CREATE TABLE utilisateur(
   id_utilisateur INT,
   Prénom VARCHAR(50),
   Nom VARCHAR(50),
   Statue VARCHAR(50),
   Téléphone INT,
   Mail VARCHAR(50),
   Mot_de_passe VARCHAR(50),
   Adresse_postale VARCHAR(255),
   PRIMARY KEY(id_utilisateur)
);

CREATE TABLE Cuisinier(
   Id_Cuisinier INT,
   id_utilisateur INT NOT NULL,
   PRIMARY KEY(Id_Cuisinier),
   UNIQUE(id_utilisateur),
   FOREIGN KEY(id_utilisateur) REFERENCES utilisateur(id_utilisateur)
);

CREATE TABLE Client(
   Id_Client INT,
   id_utilisateur INT NOT NULL,
   PRIMARY KEY(Id_Client),
   UNIQUE(id_utilisateur),
   FOREIGN KEY(id_utilisateur) REFERENCES utilisateur(id_utilisateur)
);

CREATE TABLE Plat(
   Nom_plat VARCHAR(50),
   Prix INT,
   Nationalité VARCHAR(50),
   Date_de_fabrication DATETIME,
   Date_de_péremption DATETIME,
   Nbr_part INT,
   Id_Cuisinier INT NOT NULL,
   PRIMARY KEY(Nom_plat),
   FOREIGN KEY(Id_Cuisinier) REFERENCES Cuisinier(Id_Cuisinier)
);



CREATE TABLE avis(
   Id_avis INT,
   Titre VARCHAR(50),
   Commentaire TEXT,
   Note INT,
   Id_Client INT NOT NULL,
   Id_Cuisinier INT NOT NULL,
   PRIMARY KEY(Id_avis),
   FOREIGN KEY(Id_Client) REFERENCES Client(Id_Client),
   FOREIGN KEY(Id_Cuisinier) REFERENCES Cuisinier(Id_Cuisinier)
);


CREATE TABLE Plat_Ingredient (
   Nom_plat VARCHAR(50),
   Nom_ingredient VARCHAR(50),
   PRIMARY KEY (Nom_plat, Nom_ingredient),
   FOREIGN KEY (Nom_plat) REFERENCES Plat(Nom_plat),
   FOREIGN KEY (Nom_ingredient) REFERENCES Ingrédient(Nom)
);

-- Ingrédients
INSERT INTO Ingrédient (Nom, Origine, Régime_alimentaire, certification) VALUES
('Tomate', 'Espagne', 'Végétarien', 'Bio'),
('Poulet', 'France', 'Omnivore', 'Label Rouge'),
('Saumon', 'Norvège', 'Pescetarien', 'ASC'),
('Fromage', 'Italie', 'Végétarien', 'AOP'),
('Basilic', 'France', 'Végétarien', 'Bio'),
('Ail', 'Chine', 'Végétarien', 'Non certifié'),
('Oignon', 'Espagne', 'Végétarien', 'Bio'),
('Pomme de terre', 'Allemagne', 'Végétarien', 'Bio'),
('Carotte', 'Pays-Bas', 'Végétarien', 'Bio'),
('Courgette', 'Italie', 'Végétarien', 'AOP'),
('Thon', 'Japon', 'Pescetarien', 'MSC'),
('Boeuf', 'Argentine', 'Omnivore', 'Label Rouge'),
('Lait', 'France', 'Végétarien', 'AB'),
('Beurre', 'Belgique', 'Végétarien', 'AOP'),
('Oeuf', 'France', 'Omnivore', 'Bio');

-- Utilisateurs
INSERT INTO utilisateur (id_utilisateur, Prénom, Nom, Statue, Téléphone, Mail, Mot_de_passe, Adresse_postale) VALUES
(3745352, 'Jean', 'Dupont', 'Client', 123456789, 'jean.dupont@mail.com', 'mdp123', '10 rue de Paris, France'),
(4892034, 'Marie', 'Curie', 'Client', 987654321, 'marie.curie@mail.com', 'radioactif', '15 avenue Einstein, France'),
(5928473, 'Paul', 'Bocuse', 'Cuisinier/client', 111222333, 'paul.bocuse@mail.com', 'gastronomie', '5 place des Chefs, France'),
(6134590, 'Lucie', 'Martin', 'Cuisinier/client', 324567890, 'lucie.martin@mail.com', 'cuisinepassion', '22 rue des Saveurs, France'),
(7182934, 'Hugo', 'Lemoine', 'Cuisinier/client', 456789123, 'hugo.lemoine@mail.com', 'topchef', '8 place des Gourmets, France'),
(8392011, 'Alice', 'Durand', 'Client', 789456123, 'alice.durand@mail.com', 'mangebien', '33 avenue des Papilles, France');

-- Cuisiniers
INSERT INTO Cuisinier (Id_Cuisinier, id_utilisateur) VALUES
(7839456, 5928473),
(8937451, 6134590),
(9048123, 7182934);

-- Clients
INSERT INTO Client (Id_Client, id_utilisateur) VALUES
(666, 5928473),
(6738291, 3745352),
(9823745, 4892034),
(8123471, 6134590),
(8123472, 7182934),
(8123473, 8392011);

-- Plats
INSERT INTO Plat (Nom_plat, Prix, Nationalité, Date_de_fabrication, Date_de_péremption, Nbr_part, Id_Cuisinier) VALUES
('Ratatouille', 15, 'Française', '2025-02-25 12:00:00', '2025-03-01 12:00:00', 2, 7839456),
('Sushi', 20, 'Japonaise', '2025-02-25 12:00:00', '2025-02-27 12:00:00', 4, 7839456),
('rolmops', 20, 'Japonaise', '2025-02-25 12:00:00', '2025-02-27 12:00:00', 4, 7839456),
('maquis', 20, 'Japonaise', '2025-02-25 12:00:00', '2025-02-27 12:00:00', 4, 7839456),
('Boeuf Bourguignon', 18, 'Française', '2025-03-20 12:00:00', '2025-03-22 12:00:00', 2, 8937451),
('Tajine de Poulet', 17, 'Marocaine', '2025-03-20 14:00:00', '2025-03-23 14:00:00', 3, 9048123),
('Lasagnes', 16, 'Italienne', '2025-03-20 11:00:00', '2025-03-22 11:00:00', 2, 8937451),
('moutarde', 16, 'Italienne', '2025-03-20 11:00:00', '2025-03-22 11:00:00', 2, 8937451);


-- Commandes
INSERT INTO Commande (Id_Commande, Date_commande, Prix, Temps, Statut, Id_Cuisinier, Id_Client) VALUES
(8237465, '2025-02-25 13:00:00', 35, '2025-02-25 13:30:00', 'En cours', 7839456, 6738291),
(9238475, '2025-03-20 15:00:00', 18, '2025-03-20 15:30:00', 'Livrée', 8937451, 8123473),
(9238476, '2025-03-20 15:15:00', 17, '2025-03-20 15:45:00', 'En cours', 9048123, 8123471);

-- Avis
INSERT INTO avis (Id_avis, Titre, Commentaire, Note, Id_Client, Id_Cuisinier) VALUES
(3748293, 'Délicieux', 'Le plat était excellent, bien préparé.', 5, 6738291, 7839456),
(3748299, 'pas ouf', 'Le plat était dégeu', 2, 8123472, 7839456),

(4758392, 'Parfait', 'Le boeuf était tendre et très bien assaisonné.', 5, 8123473, 8937451),
(4758393, 'Très bon', 'Bon équilibre des saveurs dans le tajine.', 4, 8123471, 9048123),
(4758394, 'Correct', 'Les lasagnes étaient bonnes mais un peu froides.', 3, 8123473, 8937451);

-- Exemples de plats livrés
INSERT INTO exemp_plat (id, adresse_liv, Nom_plat, Id_Commande) VALUES
(9283746, '10 rue de Paris, France', 'Ratatouille', 8237465),
(9283747, '33 avenue des Papilles, France', 'Boeuf Bourguignon', 9238475),
(9283748, '22 rue des Saveurs, France', 'Tajine de Poulet', 9238476);


-- Ingrédients pour Ratatouille
INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUES
('Ratatouille', 'Tomate'),
('Ratatouille', 'Courgette'),
('Ratatouille', 'Oignon'),
('Ratatouille', 'Ail'),
('Ratatouille', 'Basilic');

-- Ingrédients pour Sushi
INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUES
('Sushi', 'Saumon'),
('Sushi', 'Thon'),
('Sushi', 'Oeuf');

-- Ingrédients pour rolmops
INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUES
('rolmops', 'Thon'),
('rolmops', 'Oignon'),
('rolmops', 'Ail');

-- Ingrédients pour maquis
INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUES
('maquis', 'Saumon'),
('maquis', 'Thon'),
('maquis', 'Oeuf');

-- Ingrédients pour Boeuf Bourguignon
INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUES
('Boeuf Bourguignon', 'Boeuf'),
('Boeuf Bourguignon', 'Carotte'),
('Boeuf Bourguignon', 'Oignon'),
('Boeuf Bourguignon', 'Ail'),
('Boeuf Bourguignon', 'Beurre');

-- Ingrédients pour Tajine de Poulet
INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUES
('Tajine de Poulet', 'Poulet'),
('Tajine de Poulet', 'Carotte'),
('Tajine de Poulet', 'Oignon'),
('Tajine de Poulet', 'Ail');

-- Ingrédients pour Lasagnes
INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUES
('Lasagnes', 'Tomate'),
('Lasagnes', 'Boeuf'),
('Lasagnes', 'Fromage'),
('Lasagnes', 'Oignon'),
('Lasagnes', 'Beurre'),
('Lasagnes', 'Lait');


