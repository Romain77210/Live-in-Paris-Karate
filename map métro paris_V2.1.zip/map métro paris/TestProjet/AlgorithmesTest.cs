﻿using System.Collections.Generic;
using GrapheApp;
using Xunit;

namespace GrapheApp.Tests
{
    public class AlgorithmesTests
    {
        private List<Station> stations;
        private List<Lien> liens;
        private Station A, B, C;

        public AlgorithmesTests()
        {
            // Arrange (réseau de test simple)
            A = new Station("A", 0, 0);
            B = new Station("B", 1, 1);
            C = new Station("C", 2, 2);

            stations = new List<Station> { A, B, C };
            liens = new List<Lien>
            {
                new Lien(A, B, 5),
                new Lien(B, C, 3),
                new Lien(A, C, 10)
            };
        }


        [Fact]
        public void Dijkstra_RetourneCheminOptimal()
        {
            var chemin = Algorithmes.Dijkstra(stations, liens, A, C);

            Assert.NotNull(chemin);
            Assert.Equal(3, chemin.Count); // A -> B -> C
            Assert.Equal(new List<Station> { A, B, C }, chemin);
        }

        [Fact]
        public void BellmanFord_RetourneCheminOptimal()
        {
            var chemin = Algorithmes.BellmanFord(stations, liens, A, C);

            Assert.NotNull(chemin);
            Assert.Equal(3, chemin.Count); // A -> B -> C
            Assert.Equal(new List<Station> { A, B, C }, chemin);
        }
    }
}
