﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace GrapheApp
{
    public static class Dessinateur
    {
        public static void DessinerCarte(Graphics g, List<Station> stations, List<Lien> liens, List<Station> chemin, Size clientSize)
        {
            if (stations.Count == 0) return;

            double minLon = stations.Min(s => s.Longitude);
            double maxLon = stations.Max(s => s.Longitude);
            double minLat = stations.Min(s => s.Latitude);
            double maxLat = stations.Max(s => s.Latitude);
            Rectangle zone = new Rectangle(50, 100, clientSize.Width - 100, clientSize.Height - 150);

            // Dessiner les liens
            foreach (var l in liens)
                l.Dessiner(g, zone, minLon, maxLon, minLat, maxLat, chemin);

            // Dessiner les stations
            foreach (var s in stations)
            {
                Point p = ConvertirCoord(s, zone, minLon, maxLon, minLat, maxLat);
                Brush couleur = Brushes.LightBlue;
                if (chemin.Count > 0 && s == chemin.First()) couleur = Brushes.Green;
                if (chemin.Count > 0 && s == chemin.Last()) couleur = Brushes.Red;

                g.FillEllipse(couleur, p.X - 5, p.Y - 5, 10, 10);
                g.DrawEllipse(Pens.Black, p.X - 5, p.Y - 5, 10, 10);
                g.DrawString(s.Nom, new Font("Arial", 8), Brushes.Black, p.X + 5, p.Y + 5);
            }
        }

        private static Point ConvertirCoord(Station s, Rectangle zone, double minLon, double maxLon, double minLat, double maxLat)
        {
            int x = zone.X + (int)((s.Longitude - minLon) / (maxLon - minLon) * zone.Width);
            int y = zone.Y + (int)((maxLat - s.Latitude) / (maxLat - minLat) * zone.Height);
            return new Point(x, y);
        }
    }
}
