﻿namespace GrapheApp
{
    public class Station
    {
        public string Nom { get; }
        public double Longitude { get; }
        public double Latitude { get; }

        public Station(string nom, double lon, double lat)
        {
            Nom = nom;
            Longitude = lon;
            Latitude = lat;
        }
    }

    public class StationTemp
    {
        public string Nom { get; }
        public double Longitude { get; }
        public double Latitude { get; }


        /// <summary>
        /// Crée une nouvelle station avec un nom, une longitude et une latitude.
        /// </summary>
        /// <param name="nom">Nom de la station</param>
        /// <param name="lon">Longitude</param>
        /// <param name="lat">Latitude</param>
        public StationTemp(string nom, double lon, double lat)
        {
            Nom = nom;
            Longitude = lon;
            Latitude = lat;
        }
    }
}
