﻿using System.Collections.Generic;
using System.Drawing;

namespace GrapheApp
{
    public class Lien
    {
        public Station S1 { get; }
        public Station S2 { get; }
        public double Duree { get; }

        public Lien(Station s1, Station s2, double duree)
        {
            S1 = s1;
            S2 = s2;
            Duree = duree;
        }

        public bool Contient(Station s)
        {
            if (s == S1 || s == S2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Contient(Station a, Station b)
        {
            if ((S1 == a && S2 == b) || (S1 == b && S2 == a))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Station Autre(Station s)
        {
            if (s == S1)
            {
                return S2;
            }
            else
            {
                return S1;
            }
        }

        /// <summary>
        /// Dessine la ligne entre deux stations et affiche la durée sur une carte graphique.
        /// </summary>
        public void Dessiner(Graphics g, Rectangle zone, double minLon, double maxLon, double minLat, double maxLat, List<Station> chemin)
        {
            Point p1 = ConvertCoord(S1, zone, minLon, maxLon, minLat, maxLat);
            Point p2 = ConvertCoord(S2, zone, minLon, maxLon, minLat, maxLat);

            Pen crayon;

            if (chemin.Contains(S1) && chemin.Contains(S2))
            {
                crayon = Pens.Red;
            }
            else
            {
                crayon = Pens.Gray;
            }

            g.DrawLine(crayon, p1, p2);

            int x = (p1.X + p2.X) / 2;
            int y = (p1.Y + p2.Y) / 2;

            g.DrawString(Duree + " min", new Font("Arial", 8), Brushes.Red, x, y);
        }

        /// <summary>
        /// Convertit les coordonnées géographiques en coordonnées d'affichage dans la zone graphique.
        /// </summary>
        private Point ConvertCoord(Station s, Rectangle zone, double minLon, double maxLon, double minLat, double maxLat)
        {
            int x = zone.X + (int)((s.Longitude - minLon) / (maxLon - minLon) * zone.Width);
            int y = zone.Y + (int)((maxLat - s.Latitude) / (maxLat - minLat) * zone.Height);

            return new Point(x, y);
        }
    }
}
