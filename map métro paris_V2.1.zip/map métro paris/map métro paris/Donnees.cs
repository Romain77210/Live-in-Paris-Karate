﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace GrapheApp
{
    public static class Donnees
    {
        public static List<Station> ChargerStations(string cheminFichier, ComboBox cbDepart, ComboBox cbArrivee)
        {
            var stations = new List<Station>();

            if (!File.Exists(cheminFichier))
            {
                MessageBox.Show("Fichier MetroParis.csv non trouvé.");
                return stations;
            }

            var lignes = File.ReadAllLines(cheminFichier);
            var temp = new List<StationTemp>();

            for (int i = 1; i < lignes.Length; i++)
            {
                var parts = lignes[i].Split(',');
                if (parts.Length >= 5)
                {
                    string nom = parts[2].Trim('"');
                    if (double.TryParse(parts[3].Trim('"'), NumberStyles.Any, CultureInfo.InvariantCulture, out double lon) &&
                        double.TryParse(parts[4].Trim('"'), NumberStyles.Any, CultureInfo.InvariantCulture, out double lat))
                    {
                        temp.Add(new StationTemp(nom, lon, lat));
                    }
                }
            }

            stations = temp.GroupBy(s => s.Nom).Select(g =>
            {
                double moyLon = g.Average(s => s.Longitude);
                double moyLat = g.Average(s => s.Latitude);
                return new Station(g.Key, moyLon, moyLat);
            }).ToList();

            var noms = stations.Select(s => s.Nom).OrderBy(n => n).ToArray();
            cbDepart.Items.AddRange(noms);
            cbArrivee.Items.AddRange(noms);

            MessageBox.Show($"Stations chargées : {stations.Count}");
            return stations;
        }

        public static List<Lien> ChargerLiens(string cheminFichier, List<Station> stations)
        {
            var liens = new List<Lien>();

            if (!File.Exists(cheminFichier))
            {
                MessageBox.Show("Fichier MetroLiaisons_Lisible.csv non trouvé.");
                return liens;
            }

            var lignes = File.ReadAllLines(cheminFichier);
            for (int i = 1; i < lignes.Length; i++)
            {
                var parts = lignes[i].Split(';');
                if (parts.Length >= 3 && double.TryParse(parts[2], out double duree))
                {
                    var s1 = stations.FirstOrDefault(s => s.Nom == parts[0]);
                    var s2 = stations.FirstOrDefault(s => s.Nom == parts[1]);
                    if (s1 != null && s2 != null && s1 != s2)
                    {
                        liens.Add(new Lien(s1, s2, duree));
                    }
                }
            }

            MessageBox.Show($"Liaisons chargées : {liens.Count}");
            return liens;
        }
    }
}
