using System;
using System.Windows.Forms;

namespace GrapheApp
{
    static class Program
    {
        [STAThread]
        
        static void Main()
        {
            //styles visuels modernes de Windows (boutons, menus)
            Application.EnableVisualStyles();

            // rendu classique pour textes
            Application.SetCompatibleTextRenderingDefault(false);

            // lance  FenetreGraphe
            Application.Run(new FenetreGraphe());
        }
    }
}



/*
Program.cs	        Point d’entrée Main()
FenetreGraphe.cs	Interface graphique
Station.cs	        Station et StationTemp
Lien.cs	            Lien et dessin des liaisons
Algorithmes.cs	    Dijkstra et Bellman-Ford
Donnees.cs	        Chargement des fichiers
Dessinateur.cs	    Méthodes DessinerCarte() et ConvertirCoord()

*/