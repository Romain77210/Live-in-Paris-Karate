﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace GrapheApp
{
    public static class Algorithmes
    {
        public static List<Station> Dijkstra(List<Station> stations, List<Lien> liens, Station depart, Station arrivee)
        {
            var distances = stations.ToDictionary(s => s, s => double.MaxValue);
            var precedents = new Dictionary<Station, Station>();
            var aVoir = new HashSet<Station>(stations);

            distances[depart] = 0;

            while (aVoir.Count > 0)
            {
                var actuel = aVoir.OrderBy(s => distances[s]).First();
                aVoir.Remove(actuel);

                if (actuel == arrivee) break;

                foreach (var voisin in liens.Where(l => l.Contient(actuel)).Select(l => l.Autre(actuel)))
                {
                    if (!aVoir.Contains(voisin)) continue;

                    double nouvelleDist = distances[actuel] + liens.First(l => l.Contient(actuel, voisin)).Duree;
                    if (nouvelleDist < distances[voisin])
                    {
                        distances[voisin] = nouvelleDist;
                        precedents[voisin] = actuel;
                    }
                }
            }

            return RecomposerChemin(precedents, depart, arrivee);
        }

        public static List<Station> BellmanFord(List<Station> stations, List<Lien> liens, Station depart, Station arrivee)
        {
            var distances = stations.ToDictionary(s => s, s => double.MaxValue);
            var precedents = new Dictionary<Station, Station>();
            distances[depart] = 0;

            for (int i = 0; i < stations.Count - 1; i++)
            {
                foreach (var l in liens)
                {
                    if (distances[l.S1] + l.Duree < distances[l.S2])
                    {
                        distances[l.S2] = distances[l.S1] + l.Duree;
                        precedents[l.S2] = l.S1;
                    }
                    if (distances[l.S2] + l.Duree < distances[l.S1])
                    {
                        distances[l.S1] = distances[l.S2] + l.Duree;
                        precedents[l.S1] = l.S2;
                    }
                }
            }

            foreach (var l in liens)
            {
                if (distances[l.S1] + l.Duree < distances[l.S2] || distances[l.S2] + l.Duree < distances[l.S1])
                {
                    MessageBox.Show("Le graphe contient un cycle de poids négatif.");
                    return null;
                }
            }

            return RecomposerChemin(precedents, depart, arrivee);
        }

        private static List<Station> RecomposerChemin(Dictionary<Station, Station> precedents, Station depart, Station arrivee)
        {
            var chemin = new List<Station>();
            var u = arrivee;

            if (!precedents.ContainsKey(u) && u != depart) return null;

            while (precedents.ContainsKey(u))
            {
                chemin.Insert(0, u);
                u = precedents[u];
            }

            chemin.Insert(0, depart);
            return chemin;
        }
    }
}
